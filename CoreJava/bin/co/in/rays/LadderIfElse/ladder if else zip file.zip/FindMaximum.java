public class FindMaximum{
public static void main(String[] args){

int a,b,c;
	a=55;
	b=45;
	c=12;
if(a>b&&a>c){
	System.out.print("The Maximum number is :");
	System.out.print(a);

}
else if(b>a&&b>c){
	System.out.print("The Maximum number is :");
	System.out.print(b);

}
else{
	System.out.print("The Maximum number is :");
	System.out.print(c);

}
}
}