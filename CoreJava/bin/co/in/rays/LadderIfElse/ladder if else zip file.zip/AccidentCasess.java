public class AccidentCasess{
public static void main(String[] args){

int speed=120;

if(speed<=60){
	System.out.println("you are drive careful, very less chance to accident");
}
else if(speed<=100){
	System.out.println("you are drive fast ");
}
else{
	System.out.println("you are drive very, fast god watting for you");
}
}
}