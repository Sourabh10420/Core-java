public class Signal{

public static void main(String[] args){

String signal="red";

if(signal=="red"){
	System.out.println("Stop");
}
else if(signal=="green"){
	System.out.println("you side is clear you can go know your direction");
}
else{
	System.out.println("you can go know your direction but carefully");
}
}
}