public class FindFiger{
public static void main(String[] args){

int side=6;

if(side==10){
	System.out.println("this is a Decagon");
}
else if(side==8){
	System.out.println("this is a Octagon");
}
else if(side==7){
	System.out.println("this is a Heptagon");
}
else if(side==6){
	System.out.println("this is a Hexagon");
}
else if(side==5){
	System.out.println("this is a Pentagon");
}
else if(side==4){
	System.out.println("this is a rectangle");
}
else if(side==3){
	System.out.println("this is a Triangle");
}
else{
	System.out.println("not found");
}
}

}